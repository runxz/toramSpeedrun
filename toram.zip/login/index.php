<?php
session_start();
require '../config/db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST["username"]);
    $password = $_POST["password"];

    // Get user data
    $stmt = $pdo->prepare("SELECT userID, password, role FROM users WHERE username = :username");
    $stmt->execute(["username" => $username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user["password"])) {
        $_SESSION["userID"] = $user["userID"];
        $_SESSION["username"] = $username;
        $_SESSION["role"] = $user["role"];
        if ($user["role"] == "Moderator") {
            header("Location: ../mod"); // Redirect moderators
        } elseif($user["role"] == "Admin"){
            header("Location: ../admin"); // Redirect normal users
        }
        else {
            header("Location: ../user/dashboard.php"); // Redirect normal users
        }
        exit;
    } else {
        echo "Invalid credentials.";
    }
}
?>

<form method="POST" action="index.php">
    <input type="text" name="username" placeholder="Username" required>
    <input type="password" name="password" placeholder="Password" required>
    <button type="submit">Login</button>
</form>
