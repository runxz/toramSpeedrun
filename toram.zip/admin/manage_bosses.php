<?php


// Fetch all bosses
$stmt = $pdo->query("SELECT bossID, name, description, difficulty FROM bosses");
$bosses = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>


    <h2>Manage Bosses</h2>

    <form method="POST" action="update_boss.php">
        <input type="text" name="name" placeholder="Boss Name" required>
        <textarea name="description" placeholder="Description"></textarea>
        <select name="difficulty" required>
            <option value="Easy">Easy</option>
            <option value="Normal">Normal</option>
            <option value="Hard">Hard</option>
            <option value="Ultimate">Ultimate</option>
        </select>
        <button type="submit" name="action" value="add">Add Boss</button>
    </form>

    <table border="1">
        <thead>
            <tr>
                <th>Name</th>
                <th>Description</th>
                <th>Difficulty</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($bosses as $boss): ?>
                <tr>
                    <td><?php echo htmlspecialchars($boss["name"]); ?></td>
                    <td><?php echo htmlspecialchars($boss["description"]); ?></td>
                    <td><?php echo htmlspecialchars($boss["difficulty"]); ?></td>
                    <td>
                        <a href="edit_boss.php?bossID=<?php echo $boss['bossID']; ?>">Edit</a> | 
                        <a href="update_boss.php?bossID=<?php echo $boss['bossID']; ?>&action=delete">Delete</a>
                    </td>

                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>


