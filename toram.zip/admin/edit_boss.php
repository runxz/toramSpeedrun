<?php
session_start();
if (!isset($_SESSION["userID"]) || $_SESSION["role"] !== "Admin") {
    header("Location: ../login");
    exit;
}

require '../config/db.php';

if (!isset($_GET["bossID"])) {
    header("Location: manage_bosses.php");
    exit;
}

$bossID = $_GET["bossID"];

// Fetch boss details
$stmt = $pdo->prepare("SELECT * FROM bosses WHERE bossID = :bossID");
$stmt->execute(["bossID" => $bossID]);
$boss = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$boss) {
    die("Boss not found.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Boss</title>
</head>
<body>
    <h2>Edit Boss</h2>

    <form method="POST" action="update_boss.php">
        <input type="hidden" name="bossID" value="<?php echo $boss['bossID']; ?>">
        
        <label>Name:</label>
        <input type="text" name="name" value="<?php echo htmlspecialchars($boss['name']); ?>" required>

        <label>Description:</label>
        <textarea name="description"><?php echo htmlspecialchars($boss['description']); ?></textarea>

        <label>Difficulty:</label>
        <select name="difficulty" required>
            <option value="Easy" <?php if ($boss['difficulty'] == "Easy") echo "selected"; ?>>Easy</option>
            <option value="Normal" <?php if ($boss['difficulty'] == "Normal") echo "selected"; ?>>Normal</option>
            <option value="Hard" <?php if ($boss['difficulty'] == "Hard") echo "selected"; ?>>Hard</option>
            <option value="Ultimate" <?php if ($boss['difficulty'] == "Ultimate") echo "selected"; ?>>Ultimate</option>
        </select>

        <button type="submit" name="action" value="edit">Update Boss</button>
    </form>

    <a href="manage_bosses.php">Back to Boss Management</a>
</body>
</html>
