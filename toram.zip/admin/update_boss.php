<?php
session_start();
if (!isset($_SESSION["userID"]) || $_SESSION["role"] !== "Admin") {
    header("Location: ../login");
    exit;
}

require '../config/db.php';
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["action"])) {
    $adminID = $_SESSION["userID"];

    if ($_POST["action"] === "add") {
        $name = $_POST["name"];
        $description = $_POST["description"];
        $difficulty = $_POST["difficulty"];

        $stmt = $pdo->prepare("INSERT INTO bosses (name, description, difficulty) VALUES (:name, :description, :difficulty)");
        $stmt->execute(["name" => $name, "description" => $description, "difficulty" => $difficulty]);

        $bossID = $pdo->lastInsertId();
        logAction($pdo, $adminID, "Added new boss", "Boss", $bossID);

    } elseif ($_POST["action"] === "edit" && isset($_POST["bossID"])) {
        $bossID = $_POST["bossID"];
        $name = $_POST["name"];
        $description = $_POST["description"];
        $difficulty = $_POST["difficulty"];

        $stmt = $pdo->prepare("UPDATE bosses SET name = :name, description = :description, difficulty = :difficulty WHERE bossID = :bossID");
        $stmt->execute(["name" => $name, "description" => $description, "difficulty" => $difficulty, "bossID" => $bossID]);

        logAction($pdo, $adminID, "Edited boss", "Boss", $bossID);

    }
} elseif (isset($_GET["bossID"]) && $_GET["action"] === "delete") {
    $bossID = $_GET["bossID"];
    $adminID = $_SESSION["userID"];

    $stmt = $pdo->prepare("DELETE FROM bosses WHERE bossID = :bossID");
    $stmt->execute(["bossID" => $bossID]);

    logAction($pdo, $adminID, "Deleted boss", "Boss", $bossID);
}

header("Location: manage_bosses.php");
exit;


?>
